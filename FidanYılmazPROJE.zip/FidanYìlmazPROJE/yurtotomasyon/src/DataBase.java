public class DataBase {
    
    public static final String kullanici_adi = "root";
    public static final String parola = "fidan";
    public static final String db_ismi = "yurtotomasyon";
    public static final String host = "localhost";
    public static final int port = 3306;
    
}