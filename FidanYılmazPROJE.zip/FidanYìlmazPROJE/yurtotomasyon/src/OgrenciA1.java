
public class OgrenciA1 {
    
    private int sira;
    private String ad;
    private String soyad;
    private String oda;
    private String yatak;

    public OgrenciA1(int sira, String ad, String soyad, String oda, String yatak) {
        this.sira = sira;
        this.ad = ad;
        this.soyad = soyad;
        this.oda = oda;
        this.yatak = yatak;
    }

    public int getSira() {
        return sira;
    }

    public void setSira(int sira) {
        this.sira = sira;
    }

    public String getAd() {
        return ad;
    }

    public void setAd(String ad) {
        this.ad = ad;
    }

    public String getSoyad() {
        return soyad;
    }

    public void setSoyad(String soyad) {
        this.soyad = soyad;
    }

    public String getOda() {
        return oda;
    }

    public void setOda(String oda) {
        this.oda = oda;
    }

    public String getYatak() {
        return yatak;
    }

    public void setYatak(String yatak) {
        this.yatak = yatak;
    }
    
    
}
