-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 06 Oca 2024, 14:31:19
-- Sunucu sürümü: 10.4.28-MariaDB
-- PHP Sürümü: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `yurtotomasyon`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `a1kat`
--

CREATE DATABASE IF NOT EXISTS yurtotomasyon;

use yurtotomasyon;

CREATE TABLE `a1kat` (
  `ad` varchar(50) NOT NULL,
  `soyad` varchar(50) NOT NULL,
  `oda` varchar(50) NOT NULL,
  `yatak` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `a2kat`
--

CREATE TABLE `a2kat` (
  `sıra` int(11) NOT NULL,
  `ad` varchar(50) DEFAULT NULL,
  `soyad` varchar(50) DEFAULT NULL,
  `oda` varchar(50) DEFAULT NULL,
  `yatak` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `a3kat`
--

CREATE TABLE `a3kat` (
  `sıra` int(11) NOT NULL,
  `ad` varchar(50) DEFAULT NULL,
  `soyad` varchar(50) DEFAULT NULL,
  `oda` varchar(50) DEFAULT NULL,
  `yatak` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `admin`
--

CREATE TABLE `admin` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `admin`
--

INSERT INTO `admin` (`username`, `password`) VALUES
('fidan', 'admin');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `b1kat`
--

CREATE TABLE `b1kat` (
  `sıra` int(11) NOT NULL,
  `ad` varchar(50) DEFAULT NULL,
  `soyad` varchar(50) DEFAULT NULL,
  `oda` varchar(50) DEFAULT NULL,
  `yatak` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `b2kat`
--

CREATE TABLE `b2kat` (
  `sıra` int(11) NOT NULL,
  `ad` varchar(50) DEFAULT NULL,
  `soyad` varchar(50) DEFAULT NULL,
  `oda` varchar(50) DEFAULT NULL,
  `yatak` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `b3kat`
--

CREATE TABLE `b3kat` (
  `sıra` int(11) NOT NULL,
  `ad` varchar(50) DEFAULT NULL,
  `soyad` varchar(50) DEFAULT NULL,
  `oda` varchar(50) DEFAULT NULL,
  `yatak` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `izinal`
--

CREATE TABLE `izinal` (
  `sıra` int(11) NOT NULL,
  `ad` varchar(50) DEFAULT NULL,
  `soyad` varchar(50) DEFAULT NULL,
  `telefon` varchar(50) DEFAULT NULL,
  `tarih` date DEFAULT NULL,
  `süre` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Tablo döküm verisi `izinal`
--

INSERT INTO `izinal` (`sıra`, `ad`, `soyad`, `telefon`, `tarih`, `süre`) VALUES
(1, 'Fidan', 'Yılmaz', '05427764922', '2024-06-23', 20);

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `tumogrenciler`
--

CREATE TABLE `tumogrenciler` (
  `sıra` int(11) NOT NULL,
  `ad` varchar(50) DEFAULT NULL,
  `soyad` varchar(50) DEFAULT NULL,
  `blok` varchar(50) DEFAULT NULL,
  `kat` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `a2kat`
--
ALTER TABLE `a2kat`
  ADD PRIMARY KEY (`sıra`);

--
-- Tablo için indeksler `a3kat`
--
ALTER TABLE `a3kat`
  ADD PRIMARY KEY (`sıra`);

--
-- Tablo için indeksler `b1kat`
--
ALTER TABLE `b1kat`
  ADD PRIMARY KEY (`sıra`);

--
-- Tablo için indeksler `b2kat`
--
ALTER TABLE `b2kat`
  ADD PRIMARY KEY (`sıra`);

--
-- Tablo için indeksler `b3kat`
--
ALTER TABLE `b3kat`
  ADD PRIMARY KEY (`sıra`);

--
-- Tablo için indeksler `izinal`
--
ALTER TABLE `izinal`
  ADD PRIMARY KEY (`sıra`);

--
-- Tablo için indeksler `tumogrenciler`
--
ALTER TABLE `tumogrenciler`
  ADD PRIMARY KEY (`sıra`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `a2kat`
--
ALTER TABLE `a2kat`
  MODIFY `sıra` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `a3kat`
--
ALTER TABLE `a3kat`
  MODIFY `sıra` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `b1kat`
--
ALTER TABLE `b1kat`
  MODIFY `sıra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Tablo için AUTO_INCREMENT değeri `b2kat`
--
ALTER TABLE `b2kat`
  MODIFY `sıra` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `b3kat`
--
ALTER TABLE `b3kat`
  MODIFY `sıra` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `izinal`
--
ALTER TABLE `izinal`
  MODIFY `sıra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `tumogrenciler`
--
ALTER TABLE `tumogrenciler`
  MODIFY `sıra` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
